﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
    //Задание 11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] R = new int[25];
            Random rand = new Random();

            // Заполнение исходного массива
            for (int i = 0; i < R.Length; i++)
            {
                R[i] = rand.Next(-10, 10);
            }

            // Вывод исходного массива
            Console.WriteLine("Исходный массив R:");
            for (int i = 0; i < R.Length; i++)
            {
                Console.Write(R[i] + " ");
                if ((i + 1) % 10 == 0) // Перенос строки каждые 10 элементов для удобства
                    Console.WriteLine();
            }
            if (R.Length % 10 != 0) Console.WriteLine(); // Завершающий перенос строки

            
          
            for (int i = 0; i < R.Length; i++)
            {
                if (R[i] < 0)
                    R[i] = R[i] * R[i];
                else if (R[i] > 0)
                    R[i] += 7;
                // нулевые элементы остаются без изменений
            }

            // Вывод модифицированного массива
            Console.WriteLine("\nМодифицированный массив R:");
            for (int i = 0; i < R.Length; i++)
            {
                Console.Write(R[i] + " ");
                if ((i + 1) % 10 == 0)
                    Console.WriteLine();
            }
            if (R.Length % 10 != 0) Console.ReadLine();
        }
    
}
    }


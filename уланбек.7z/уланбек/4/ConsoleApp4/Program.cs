﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
    //Задание 23
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] A = new int[12];
            Random rand = new Random();

            // Заполнение исходного массива случайными числами от -20 до 20
            for (int i = 0; i < A.Length; i++)
                A[i] = rand.Next(-20, 21);

            // Вывод исходного массива
            Console.WriteLine("Исходный массив A (12 элементов):");
            PrintArray(A);

            // Сумма чётных элементов (включая отрицательные чётные и ноль)
            int sum = 0;
            for (int i = 0; i < A.Length; i++)
            {
                if (A[i] % 2 == 0) // чётное число
                    sum += A[i];
            }

            Console.WriteLine($"\nСумма чётных элементов: {sum}");
        }

        static void PrintArray(int[] arr)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i].ToString().PadLeft(4) + " ");
                if ((i + 1) % 6 == 0) // перенос каждые 6 элементов для компактности (12/2)
                    Console.WriteLine();
            }
            if (arr.Length % 6 != 0) Console.WriteLine();
        }
    }
}
  

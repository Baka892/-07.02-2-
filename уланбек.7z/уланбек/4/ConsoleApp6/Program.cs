﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    //Задание 24
    class Program
    {
        static void Main(string[] args)
        {
            int[] A = new int[15];
            Random rand = new Random();

            // Заполнение исходного массива случайными числами от -20 до 20
            for (int i = 0; i < A.Length; i++)
                A[i] = rand.Next(-20, 21);

            // Вывод исходного массива
            Console.WriteLine("Исходный массив A:");
            PrintArray(A);

            // Создаём копию для модификации (или можно менять A напрямую — здесь меняем A)
            for (int i = 0; i < A.Length; i++)
            {
                if (A[i] > 0)
                    A[i] = A[i] * A[i];   // положительные → в квадрат
                else if (A[i] < 0)
                    A[i] = A[i] * 2;      // отрицательные → умножить на 2
                                          // нули остаются без изменений
            }

            // Вывод модифицированного массива
            Console.WriteLine("\nМодифицированный массив A:");
            PrintArray(A);
        }

        static void PrintArray(int[] arr)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i].ToString().PadLeft(4) + " ");
                if ((i + 1) % 5 == 0) // перенос каждые 5 элементов (15/3 = удобно)
                    Console.WriteLine();
            }
            if (arr.Length % 5 != 0) Console.WriteLine();
        }
    }
}
    

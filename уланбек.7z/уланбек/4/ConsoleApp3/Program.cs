﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    //Задание 13
    class Program
    {
        static void Main(string[] args)
        {
            int[] A = new int[30];
            Random rand = new Random();

            // Заполнение исходного массива случайными числами от -20 до 20
            for (int i = 0; i < A.Length; i++)
                A[i] = rand.Next(-20, 21);

            // Вывод исходного массива
            Console.WriteLine("Исходный массив A:");
            PrintArray(A);

            // Вычисление суммы нечётных отрицательных элементов
            int sum = 0;
            for (int i = 0; i < A.Length; i++)
            {
                if (A[i] < 0 && A[i] % 2 != 0) // отрицательное И нечётное
                    sum += A[i];
            }

            Console.WriteLine($"\nСумма нечётных отрицательных элементов: {sum}");
        }

        static void PrintArray(int[] arr)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i].ToString().PadLeft(4) + " ");
                if ((i + 1) % 10 == 0) Console.WriteLine();
            }
            if (arr.Length % 10 != 0) Console.WriteLine();
        }
    }
}
        
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        //Задание 2
        static void Main(string[] args)
        {
            const int size = 3;
            int[,] matrix = new int[size, size];

            // Заполнение матрицы случайными числами от 1 до 10
            Random rand = new Random();
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    matrix[i, j] = rand.Next(1, 11);
                }
            }

            // Вывод исходной матрицы
            Console.WriteLine("Исходная матрица A(3,3):");
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    Console.Write($"{matrix[i, j],4}");
                }
                Console.WriteLine();
            }

            // Вычисление суммы второй строки (индекс 1)
            int sumSecondRow = 0;
            for (int j = 0; j < size; j++)
            {
                sumSecondRow += matrix[1, j];
            }

            // Вычисление произведения первого столбца (индекс 0)
            long productFirstColumn = 1; // Используем long для избежания переполнения
            for (int i = 0; i < size; i++)
            {
                productFirstColumn *= matrix[i, 0];
            }

            // Вывод результатов
            Console.WriteLine($"\nСумма элементов второй строки: {sumSecondRow}");
            Console.WriteLine($"Произведение элементов первого столбца: {productFirstColumn}");
            Console.ReadLine();
        }
    }
}
    

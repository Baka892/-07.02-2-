﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    //Задание 1
    internal class Program
    {
        static void Main(string[] args)
        {
            const int rows = 3;
            const int cols = 4;
            int[,] matrix = new int[rows, cols];

            // Заполнение матрицы случайными числами от -50 до 50
            Random rand = new Random();
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    matrix[i, j] = rand.Next(-50, 51);
                }
            }

            // Вывод исходной матрицы
            Console.WriteLine("Исходная матрица A(3,4):");
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    Console.Write($"{matrix[i, j],5}");
                }
                Console.WriteLine();
            }

            // Поиск минимального элемента в каждой строке
            Console.WriteLine("\nНаименьшие элементы в каждой строке:");
            for (int i = 0; i < rows; i++)
            {
                int min = matrix[i, 0]; // Предполагаем, что первый элемент — минимальный
                for (int j = 1; j < cols; j++)
                {
                    if (matrix[i, j] < min)
                        min = matrix[i, j];
                }
             
                Console.WriteLine($"Строка {i + 1}: {min}");
            }
            Console.ReadLine();

        }
    }
}
 

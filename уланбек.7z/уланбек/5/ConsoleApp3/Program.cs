﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    //Задаине 3
    internal class Program
    {
        static void Main(string[] args)
        {
            const int size = 4;
            int[,] matrix = new int[size, size];

            // Заполнение матрицы случайными числами от -50 до 50
            Random rand = new Random();
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    matrix[i, j] = rand.Next(-50, 51);
                }
            }

            // Вывод исходной матрицы с выделением главной диагонали
            Console.WriteLine("Исходная матрица A(4,4):");
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    if (i == j)
                        Console.ForegroundColor = ConsoleColor.Blue; // Выделяем диагональ
                    Console.Write($"{matrix[i, j],5}");
                    Console.ResetColor();
                }
                Console.WriteLine();
            }

            // Поиск наибольшего элемента на главной диагонали
            int maxDiagonal = matrix[0, 0];
            for (int i = 1; i < size; i++)
            {
                if (matrix[i, i] > maxDiagonal)
                    maxDiagonal = matrix[i, i];
            }

            // Вывод результата
            Console.WriteLine($"\nНаибольший элемент на главной диагонали: {maxDiagonal}");
            Console.ReadLine();
        }
    }
}
        

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Program
    {
        //Задание 6
        static void Main(string[] args)
        {
            const int rows = 4;
            const int cols = 3;
            int[,] matrix = new int[rows, cols];

            // Заполнение матрицы случайными числами от -50 до 50
            Random rand = new Random();
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    matrix[i, j] = rand.Next(-50, 51);
                }
            }

            // Вывод исходной матрицы с подсветкой положительных элементов
            Console.WriteLine("Исходная матрица A(4,3):");
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    if (matrix[i, j] > 0)
                        Console.ForegroundColor = ConsoleColor.Green;
                    else if (matrix[i, j] < 0)
                        Console.ForegroundColor = ConsoleColor.Red;
                    else
                        Console.ForegroundColor = ConsoleColor.Yellow; // ноль

                    Console.Write($"{matrix[i, j],5}");
                    Console.ResetColor();
                }
                Console.WriteLine();
            }

            // Подсчёт количества положительных элементов
            int positiveCount = 0;
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    if (matrix[i, j] > 0)
                        positiveCount++;
                }
            }

            // Вывод результата
            Console.WriteLine($"\nКоличество положительных элементов: {positiveCount}");
            Console.ReadLine();
        }
    }
}
        

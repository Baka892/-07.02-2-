﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Program
    {
        //Задание 5
        static void Main(string[] args)
        {
            const int rows = 4;
            const int cols = 3;
            int[,] matrix = new int[rows, cols];

            // Заполнение матрицы случайными числами от -100 до 100
            Random rand = new Random();
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    matrix[i, j] = rand.Next(-100, 101);
                }
            }

            // Вывод исходной матрицы
            Console.WriteLine("Исходная матрица A(4,3):");
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    Console.Write($"{matrix[i, j],5}");
                }
                Console.WriteLine();
            }

            // Поиск наибольшего элемента во всей матрице
            int maxElement = matrix[0, 0];
            int maxRow = 0, maxCol = 0;

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    if (matrix[i, j] > maxElement)
                    {
                        maxElement = matrix[i, j];
                        maxRow = i;
                        maxCol = j;
                    }
                }
            }

            // Вывод результата
            Console.WriteLine($"\nНаибольший элемент матрицы: {maxElement}");
            //Console.WriteLine($"Позиция: строка {maxRow + 1}, столбец {maxCol + 1}");
            Console.ReadLine();
        }
    }
}
        
